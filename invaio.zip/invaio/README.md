# Summary

This repo contains terraform for managing AWS resources for Invaio Sciences via code and storing the state centrally in omegatx-central (181562839769) us-east-1.

## Prequisites

### Download terraform executable

    https://www.terraform.io/downloads.html

### AWS CLI Install

[Install the AWS CLI](https://docs.aws.amazon.com/cli/latest/userguide/cli-chap-install.html)

### AWS Profile

In `~/.aws/credentials`

```shell
[invaio]
aws_access_key_id = ____________________
aws_secret_access_key = ________________________________________
```

In `~/.aws/config`

```shell
[invaio]
region = us-east-1
```

### References

    Terraform Docs: https://www.terraform.io/docs/index.html


### Submitting Nextflow Jobs

1. Upload your nextflow file(s) to s3://nextflow-work-390342521138/pipelines/<PIPELINENAME>
2. Upload a nextflow.config (see example) to s3://nextflow-work-390342521138/pipelines/<PIPELINENAME>
3. Submit the job from any machine that has AWS access and permissions:
`aws batch submit-job --job-name <JOBNAME> --job-queue head --job-definition nf-head --container-overrides "environment=[{name=PIPELINE_NAME,value=<PIPELINENAME>}]"`
4. When all of the pipelines are complete, results will be in s3://nextflow-data-390342521138/results/<AWS_BATCH_JOB_ID>

### Sample Nextflow Config
```
profiles {
  batch {
    aws.region = 'us-east-1'
    process.container = 'nextflow/rnaseq-nf:s3'
    process.executor = 'awsbatch'
    process.queue = 'worker-queue'
  }
}

tower {
  enabled = true
  accessToken = 'youraccesstokengoeshere'
  workspaceId = 'theworkspaceid'
}
