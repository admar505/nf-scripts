# S3 Backend Configuration

CloudFormation is used to deploy resources used by the Terraform [S3 backend](https://www.terraform.io/docs/backends/types/s3.html).  Managing the backend resources in CloudFormation, rather than Terraform, prevents cyclical dependencies.

This deployment will serve Terraform 0.12.x or greater.

## Table of Contents

- [S3 Backend Configuration](#s3-backend-configuration)
  - [Table of Contents](#table-of-contents)
  - [AWS Resource Usage](#aws-resource-usage)
  - [Deployment](#deployment)
    - [AWS Console Deployment](#aws-console-deployment)
    - [Script Deployment](#script-deployment)
  - [Example Backend](#example-backend)

## AWS Resource Usage

The following resources are created:

- S3 bucket for state file storage with versioning enabled, public access **blocked**, and deletion protection via S3 policy.
- KMS key used to encrypt state files in S3
- DynamoDB table for maintaining [state locks](https://www.terraform.io/docs/state/locking.html)

![diagram](docs/diagram.png)

## Deployment

You can choose between an AWS console deployment or a script based deployment.

### AWS Console Deployment

Consider that S3 bucket names are unique and name your state bucket accordingly.  Generally, `terraform-AWS_ACCOUNT_ID` is recommended.

Deploy the stack via the [CloudFormation console](https://console.aws.amazon.com/cloudformation/home?) with parameters similar to the following:

![console-parameters](docs/console-parameters.png)

Post-deployment, take note of the stack `Outputs` tab.  Values here will be used to populate your Terraform backend configuration.

![console-outputs](docs/console-outputs.png)

### Script Deployment

The `deploy-backend.sh` script will deploy the CloudFormation based backend via the CLI and generate a Terraform backend configuration.  It deploys with the following assumptions:

- The required version of Terraform will be the same as your current version
- S3 bucket name will be `terraform-<AWS_ACCOUNT_ID>`
- KMS key alias will be `terraform`
- DynamoDB lock table name will be `terraform-lock`

Run this script from its local directory, providing arguments of an AWS profile name and AWS region, respectively.  If the script is run with no arguments, it will provide usage.

Example usage:

```bash
❯ ./deploy-backend.sh privo-support-example-client us-east-1

Profile: privo-support-example-client
Region: us-east-1


Ready for creation? (y/n): y
Deployment started.. waiting for CREATE_COMPLETE...
Use the following values as your terraform S3 backend definition:

terraform {
  required_version = "0.14.3"
  backend "s3" {
    bucket         = "terraform-000000000000"
    dynamodb_table = "terraform-lock"
    kms_key_id     = "arn:aws:kms:us-east-1:000000000000:key/5efb2fbc-xxxx-xxxx-xxxx-b73b69fc1ceb"
    key            = "***SET_A_FILE_NAME_HERE***.tfstate"
    region         = "us-east-1"
    encrypt        = "true"
    profile        = "privo-support-example-client"
  }
}
```

Set the desired S3 key name in the output above in place of the `***SET_A_FILE_NAME_HERE***` text.

## Example Backend

In your Terraform working directory, create a `backend.tf` file.  If you created your backend with the script, copy the script's output, adjust the key, and you're done!

If you executed a console deployment, open the CloudFormation stack `Outputs` tab.  The values under that tab will be used to populate the example backend definition below.

Note that this backend definition may exist in any `.tf` file, but Privo best practices dictate that you create a separate `backend.tf` to manage your configuration more cleanly.

Adjust the `required_version` accordingly.  It is considered a best practice to "pin" the version as one user updating can force all other users to require updates.   Pinning forces a conversation before adjusting.  For more details, see the [Terraform Settings documentation](https://www.terraform.io/docs/configuration/terraform.html).

```terraform
terraform {
  required_version = "0.12.18"
  backend "s3" {
    bucket         = <VALUE_FROM_CLOUDFORMATION_OUTPUT>
    dynamodb_table = <VALUE_FROM_CLOUDFORMATION_OUTPUT>
    key            = "my-state.tfstate"
    kms_key_id     = <VALUE_FROM_CLOUDFORMATION_OUTPUT>
    region         = "us-east-1"
    encrypt        = "true"
    profile        = <YOUR_LOCAL_AWS_PROFILE>
  }
}
```
