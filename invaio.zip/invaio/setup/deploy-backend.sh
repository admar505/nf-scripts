#!/bin/bash

set -eo pipefail

export AWS_PAGER=""
export DYNAMO_TABLE_NAME="terraform-lock"
export AWS_PROFILE="$1"
export AWS_DEFAULT_REGION="$2"
STACK_LOCAL_PATH="./terraform-backend.yml"
STACK_NAME="terraform-backend"
TF_VERSION=$(terraform --version | grep '^Terra' | cut -d v -f 2)

function usage {
cat <<EOF
  Run this script from its local directory.

  Usage: ./deploy-backend.sh <AWS_PROFILE_NAME> <REGION>

  Example: ./deploy-backend.sh privo-support-client-example us-east-1
  You'll be prompted for creation confirmation before registration is executed.
EOF
}

if [ $# -lt 2 ]; then
    echo "All arguments are required."
    usage
    exit
fi

# Variables dependent on proper arguments
export ACCOUNT_ID=$(aws sts get-caller-identity --query Account --output text)
export BUCKET_NAME="terraform-$ACCOUNT_ID"

read -p "$(echo -e "\nProfile: $AWS_PROFILE\nRegion: $AWS_DEFAULT_REGION\n\n\nReady for creation? (y/n):") " -n 1 -r
echo ""

if [[ $REPLY =~ ^[Yy]$ ]]; then

    aws cloudformation create-stack \
        --stack-name "$STACK_NAME" \
        --template-body "file://$STACK_LOCAL_PATH" \
        --parameters ParameterKey=pKMSkeyAlias,ParameterValue=terraform ParameterKey=pBucketName,ParameterValue=terraform-"$ACCOUNT_ID" ParameterKey=pDynamoTableName,ParameterValue=terraform-lock

    echo "Deployment started.. waiting for CREATE_COMPLETE..."
    aws cloudformation wait stack-create-complete --stack-name "$STACK_NAME"

    KMS_KEY_ARN=$(aws cloudformation describe-stacks \
                      --stack-name "$STACK_NAME" \
                      --query "Stacks[0].Outputs[?OutputKey == \`kmsKeyArn\`].OutputValue" \
                      --output text)

    echo -e "Use the following values as your terraform S3 backend definition:\n"
cat << EOF
terraform {
  required_version = "$TF_VERSION"
  backend "s3" {
    bucket         = "$BUCKET_NAME"
    dynamodb_table = "$DYNAMO_TABLE_NAME"
    kms_key_id     = "$KMS_KEY_ARN"
    key            = "***SET_A_FILE_NAME_HERE***.tfstate"
    region         = "$AWS_DEFAULT_REGION"
    encrypt        = "true"
    profile        = "$AWS_PROFILE"
}
EOF

fi