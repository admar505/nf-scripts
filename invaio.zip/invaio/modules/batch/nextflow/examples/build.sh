#!/bin/bash

set -e

ACCOUNT_ID=$(aws sts get-caller-identity --query Account --output text)

if [ -z "$AWS_REGION" ]; then
    AWS_REGION=`aws configure get region`
fi

echo "Docker Login to ECR"
aws ecr get-login-password | docker login --username AWS --password-stdin ${ACCOUNT_ID}.dkr.ecr.${AWS_REGION}.amazonaws.com
echo "Building container..."
docker build -t nextflow docker/nextflow
echo "Tagging container image"
docker tag nextflow:latest ${ACCOUNT_ID}.dkr.ecr.${AWS_REGION}.amazonaws.com/nextflow-head:latest
echo "Pushing container image to ECR"
docker push ${ACCOUNT_ID}.dkr.ecr.${AWS_REGION}.amazonaws.com/nextflow-head:latest
