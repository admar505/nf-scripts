# Module - Nextflow on AWS Batch

- [Module - Nextflow on AWS Batch](#module---nextflow-on-aws-batch)
  - [Minimum Required Configuration](#minimum-required-configuration)
  - [Example Usage](#example-usage)
  - [Example Workflows](#example-workflows)
    - [Paired-fastqs to uBAM](#paired-fastqs-to-ubam)


This module deploys all the necessary bits to run Nextflow on AWS Batch. It is intended for you to utilize the "batch squared" methodology - that is, launching a single Batch job to run multiple Batch jobs. You can read more about Batch squared [here](https://catalog.us-east-1.prod.workshops.aws/v2/workshops/8213ad51-878f-493b-8e5a-fbea22c4360c/en-US/squared).

## Minimum Required Configuration

```terraform
module "nextflow" {
  source             = "../relative/path/to/modules/batch-nextflow"
  subnet_ids         = ["subnet-XXXXXXXX", "subnet-YYYYYYYY"]
  vpc_id             = "vpc-XXXXXXXX"
  nextflow_bucket_id = "yournextflows3bucket"
}
```
NOTE: Creation of an S3 Bucket is decoupled from the module to prevent accidental deletion.

NOTE (again): After you deploy the module you need to manually build and push the Nextflow Docker image into ECR. There's a script to help with that `examples/build.sh`. Eventually this will be automatically deployed with a Code Pipeline project.

## Example Usage

Once the cluster is up and running use the `submit-workflow.sh` bash script to submit jobs to the cluster. Here's an example:

`$ ./submit-workflow.sh myworkflow rnatoy`

You can also upload your workflow to an S3 bucket and run it like so:

`$ ./submit-workflow.sh myworkflow s3://nextflow-12345678910/pipelines/rnatoy`

## Example Workflows

There are a few workflows located in `examples/workflows` you can use to test your cluster.

### Paired-fastqs to uBAM

Edit `workflows/paired-fastq-to-ubam/nextflow.config` as needed.

Upload the entire workflow directory to s3:

```
aws s3 cp --recursive paired-fastq-to-ubam s3://yournextflows3bucket/pipelines/paired-fastq-to-ubam/
```

Create a config:
```
cat <<EOF >>paired-fastq-to-ubam.json
{
    "command": [
      "s3://yournextflows3bucket/pipelines/paired-fastq-to-ubam/",
      "--outdir", "s3://yournextflows3bucket/paired-fastq-to-ubam-results/"
    ]
}
EOF
```

Submit the job:

```bash
./submit-workflow.sh mytestworkflow file://paired-fastq-to-ubam.json
```

### Per-Sample Variant Calling

NOTE: This workflow can only be run _after_ Paired-fastqs to uBAM.

Edit `workflows/paired-fastq-to-ubam/nextflow.config` as needed.

Upload the entire workflow directory to s3:

```
aws s3 cp --recursive persample-variant-calling s3://yournextflows3bucket/pipelines/persample-variant-calling/
```

Create a config:
```
cat <<EOF >>persample-variant-calling.json
{
    "command": [
      "s3://yournextflows3bucket/pipelines/persample-variant-calling/",
      "--unmapped_bams_list", "s3://yournextflows3bucket/paired-fastq-to-ubam-results/unmapped_bams.tsv",
      "--outdir", "s3://yournextflows3bucket/persample-variant-calling-results/",
      "--projectId", "myproject"
    ]
}
EOF
```

Submit the job:

```bash
./submit-workflow.sh mytestworkflow2 file://persample-variant-calling.json
```

<!-- BEGINNING OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >= 0.13.1 |
| <a name="requirement_aws"></a> [aws](#requirement\_aws) | >= 3.0 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | >= 3.0 |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [aws_batch_compute_environment.default](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/batch_compute_environment) | resource |
| [aws_batch_compute_environment.highpriority](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/batch_compute_environment) | resource |
| [aws_batch_job_definition.this](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/batch_job_definition) | resource |
| [aws_batch_job_queue.default](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/batch_job_queue) | resource |
| [aws_batch_job_queue.highpriority](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/batch_job_queue) | resource |
| [aws_ecr_repository.this](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/ecr_repository) | resource |
| [aws_iam_instance_profile.batch_instance_role](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_instance_profile) | resource |
| [aws_iam_role.batch_instance_role](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_role) | resource |
| [aws_iam_role.batch_service_role](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_role) | resource |
| [aws_iam_role.spot_fleet](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_role) | resource |
| [aws_iam_role_policy.batch_instance_role1](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_role_policy) | resource |
| [aws_iam_role_policy.batch_instance_role2](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_role_policy) | resource |
| [aws_iam_role_policy.batch_instance_role3](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_role_policy) | resource |
| [aws_launch_template.this](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/launch_template) | resource |
| [aws_security_group.default](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/security_group) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_batch_default_name"></a> [batch\_default\_name](#input\_batch\_default\_name) | Name of the default (Spot) Batch Compute Environment | `string` | `"workers"` | no |
| <a name="input_batch_highpriority_name"></a> [batch\_highpriority\_name](#input\_batch\_highpriority\_name) | Name of the high priority (On Demand) Batch Compute Environment | `string` | `"head"` | no |
| <a name="input_bid_percentage"></a> [bid\_percentage](#input\_bid\_percentage) | Integer of minimum percentage that a Spot Instance price must be when compared to on demand.  Example: A value of 20 would require the spot price be lower than 20% the current on demand price. | `string` | `"100"` | no |
| <a name="input_default_max_vcpus"></a> [default\_max\_vcpus](#input\_default\_max\_vcpus) | The maximum number of CPUs for the default (Spot) Batch Compute Environment | `number` | `96` | no |
| <a name="input_ecr_repo"></a> [ecr\_repo](#input\_ecr\_repo) | Name of repo for storing Docker image used for Nextflow submissions | `string` | `"nextflow-head"` | no |
| <a name="input_highpriority_max_vcpus"></a> [highpriority\_max\_vcpus](#input\_highpriority\_max\_vcpus) | The maximum number of CPUs for the high priority (On Demand) Batch Compute Environment | `number` | `96` | no |
| <a name="input_nextflow_bucket_name"></a> [nextflow\_bucket\_name](#input\_nextflow\_bucket\_name) | Name of an EXISTING S3 Bucket which will be used to store Nextflow intermediate files, logs, and status. | `string` | n/a | yes |
| <a name="input_scratch_volume_initial_size"></a> [scratch\_volume\_initial\_size](#input\_scratch\_volume\_initial\_size) | Initial size in GB of autoscaling scratch space volume. | `number` | `100` | no |
| <a name="input_security_group_ids"></a> [security\_group\_ids](#input\_security\_group\_ids) | List of additional security groups to associate with cluster instances. | `list(any)` | `[]` | no |
| <a name="input_subnet_ids"></a> [subnet\_ids](#input\_subnet\_ids) | List of subnets cluster instances will be deployed in. | `list(string)` | n/a | yes |
| <a name="input_vpc_id"></a> [vpc\_id](#input\_vpc\_id) | VPC ID | `string` | n/a | yes |

## Outputs

No outputs.
<!-- END OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
